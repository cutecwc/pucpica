const carousel = document.querySelector('.image-carousel');
const container = carousel.querySelector('.image-carousel-container');
const prevButton = carousel.querySelector('.prev');
const nextButton = carousel.querySelector('.next');
const images = container.querySelectorAll('img');

let currentIndex = 0;
let intervalId;

function nextImage() {
  currentIndex++;
  if (currentIndex >= images.length) {
    currentIndex = 0;
  }
  const translateX = -currentIndex * 25;
  container.style.transform = `translateX(${translateX}%)`;
}

function prevImage() {
  currentIndex--;
  if (currentIndex < 0) {
    currentIndex = images.length - 1;
  }
  const translateX = -currentIndex * 25;
  container.style.transform = `translateX(${translateX}%)`;
}

nextButton.addEventListener('click', nextImage);
prevButton.addEventListener('click', prevImage);

intervalId = setInterval(() => {
  nextImage();
}, 3000);

carousel.addEventListener('mouseenter', () => {
  clearInterval(intervalId);
});

carousel.addEventListener('mouseleave', () => {
  intervalId = setInterval(() => {
    nextImage();
  }, 3000);
});
